<?php
//https://stackoverflow.com/questions/45711303/wordpress-and-jwt-with-custom-api-rest-endpoint
//https://wordpress.org/support/topic/custom-endpoint-is-unprotected/
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Plugin Name: Stnc Quizcat Extra V2
 * Plugin URI: selmantunc.com.tr
 * Description: stnc quizcat extra (rest api endpoints add)
 * Author: stnc
 * Author URI: http://selmantunc.com.tr
 * Version: 2.0.0
 *
 */
//TODO: like olayı senkron olacak __liked diye bir gonderdim yapıyorum şu an
$CHfw_meta_key = 'wowPostSetting';

global $stncCatQuiz;
$stncCatQuiz = "1.0.0";

require_once "plugin_install.php";

// require_once "admin_menu.php";

require_once "helper.php";

require_once "modifications.php";

require_once "post_metabox.php";

require_once "rest_api.php";

//////******OTHER FUNC (for  * Gets quiz id request)

//https://wordpress.org/support/topic/feature-request-get_current_user_id/

add_filter('jwt_auth_token_before_dispatch', 'stnc_jwt_auth_token_extra_fields', 10, 2);

/**
 * Adds a website parameter to the auth.
 *
 */
function stnc_jwt_auth_token_extra_fields($data, $user)
{
    //  $data['website'] = 'https://mysite.com';
    //   print_r($user);
    //   return
    //   print_r(    get_userdata($user->data->ID ));
    // //https://developer.wordpress.org/reference/functions/get_the_author_meta/
    //   print_r( get_the_author_meta( 'description',  $user->data->ID ));

    $data['user_id'] = $user->data->ID;
    $data['registered_date'] = $user->data->user_registered;
    $data['url'] = $user->data->user_url;
    $data['display_name'] = $user->data->display_name;
    $data['user_registered'] = $user->data->user_registered;
    $data['description'] = get_user_meta($user->data->ID, 'description', true);
    $data['avatar120'] = get_avatar_url($user->data->ID, 120); // $a= get_avatar( $user->data->ID, 120);
    $data['webSite'] = get_the_author_meta('user_url', $user->data->ID);
    $data['slug'] = $user->data->user_login;

    return $data;
}

/******************************************************
 ** Paste As Text by Default in WordPress -start ******
 ******************************************************/

//add_filter( 'default_content', 'my_editor_content', 10, 2 ); //closed  // (Not used )

function my_editor_content($content, $post)
{

    switch ($post->post_type) {
        case 'sources':
            $content = 'your content';
            break;
        case 'stories':
            $content = 'your content';
            break;
        case 'pictures':
            $content = 'your content';
            break;
        default:
            $content = 'your default content';
            break;
    }

    return $content;
}
