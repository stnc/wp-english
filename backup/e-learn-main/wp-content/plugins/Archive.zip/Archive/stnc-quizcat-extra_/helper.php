<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Helper array shuffle
 * @param array $list The request sent from WP REST API.
 * @return array random array list
 */
function shuffle_assoc($list)
{
    if (!is_array($list)) {
        return $list;
    }

    $keys = array_keys($list);
    shuffle($keys);
    $random = array();
    foreach ($keys as $key) {
        $random[$key] = $list[$key];
    }
    return $random;
}


/**
 * Get User Status (like/dislike)  -- for  
 * @param           int $post_id
 * @since           1.0
 * @return            int
 */
function get_total_like_all($post_id)
{
    global $wpdb;

    $query = " SELECT count(id)	FROM " . esc_sql($wpdb->prefix . 'ulike') . " WHERE `post_id` = '" . esc_sql($post_id) . "' ";

    $result = $wpdb->get_var($query);

    return empty($result) ? 0 : $result;
}


/**
 * Get User Status (like/dislike)  -- for  
 * @param           int $post_id
 * @since           1.0
 * @return            int
 */
function get_total_like_for_like($post_id)
{
    global $wpdb;

    $query = "
					SELECT count(id)
					FROM " . esc_sql($wpdb->prefix . 'ulike') . "
					WHERE `post_id` = '" . esc_sql($post_id) . "' AND `status` ='like'  ";

    $result = $wpdb->get_var($query);

    return empty($result) ? 0 : $result;
}

/**
 * Get User Status (like/dislike)  -- for 
 * @param           int $post_id
 * @since           1.0
 * @return            int
 */
function get_total_like_for_like_userME($post_id,$userId)
{
    global $wpdb;

    $query = "
					SELECT status
					FROM " . esc_sql($wpdb->prefix . 'ulike') . "
					WHERE `post_id` = '" . esc_sql($post_id) . "' AND `status` ='like' AND `user_id` = '" . esc_sql($userId) . "'  ";

    $result = $wpdb->get_var($query);

    return empty($result) ? 'unlike' : $result;
}