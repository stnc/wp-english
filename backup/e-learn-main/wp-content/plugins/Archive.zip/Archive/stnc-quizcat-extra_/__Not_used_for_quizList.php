<?php
if (!defined('ABSPATH')) {
    exit;
}



function stnc_quiz_func_manipulationV1($datas)
{
    foreach ($datas['questions'] as $key => $data) {
        foreach ($data['answers'] as $keyAnswer => $answer) {
            //burada da bir foreach olmalı onun içinde işleme gitmeli
            $datas['questions'][$key]['correctoption'] = 0;
            $datas['questions'][$key]['answers'][$keyAnswer]['id'] = $keyAnswer;
        }
        shuffle($datas['questions'][$key]['answers']);
    }
    return $datas;
}

function stnc_quiz_func_manipulationV2($datas)
{
    foreach ($datas['questions'] as $key => $data) {
        foreach ($data['answers'] as $keyAnswer => $answer) {
            $datas['questions'][$key]['answers']['answers' . $keyAnswer] = $answer;
            $datas['questions'][$key]['answers']['answers' . $keyAnswer]['id'] = $keyAnswer;
            unset($datas['questions'][$key]['answers'][$keyAnswer]);
        }
        // shuffle( $datas['questions'][$key]['answers']);
    }

    return $datas;
}

function stnc_quiz_func_manipulationV3($datas)
{
    $i = 0;
    foreach ($datas['questions'] as $key => $data) {
        $i++;
        unset($datas['questions'][$key]);
        $datas['questions'][$key]['question' . $key] = $data;
        foreach ($datas['questions'][$key]["question$key"]['answers'] as $keyAnswer => $answer) {
            $datas['questions'][$key]["question$key"]['answers']['answers' . $keyAnswer] = $answer['answer'];
            $datas['questions'][$key]["question$key"]['correctOption'] = 'answers0';
            unset($datas['questions'][$key]["question$key"]['answers'][$keyAnswer]);
            $datas['questions'][$key]["question$key"]['answers'] = shuffle_assoc($datas['questions'][$key]["question$key"]['answers']);
        }
    }

    //   print_r ($datas);
    return $datas;
}




// NOT USED 
/*******************************************************
 *************  quizlcat id listesi -start (REST API) 
///--- not used  ***
 *******************************************************/


//http://wp.test/wp-json/wp/v2/quizcatforIds
add_action('rest_api_init', 'register_quizcatforIds_id');
function register_quizcatforIds_id()
{
    register_rest_route('wp/v2', '/quizcatforIds/',
        array(
            'methods' => 'GET',
            'callback' => 'stnc_quizcatforIds_id',
            'permission_callback' => function ($request) {
                return is_user_logged_in();
            },
        )
    );
}

function stnc_quizcatforIds_id()
{
    $loop = new WP_Query(array('post_type' => 'fca_qc_quiz', 'posts_per_page' => -1));
    while ($loop->have_posts()): $loop->the_post();
        $newArr['idlist'][] = [
            'id' => get_the_ID(),
        ];
    endwhile;
    return $newArr;
}


///not used
function stnc_quizcat_save_question_counter()
{
    global $wpdb;
    global $tableName;
    $sql = "SELECT count(*) FROM  $tableName WHERE `quiz_id` = '1' and `user_id` = '1' and `post_id`='1' ";
    $rowcount = $wpdb->get_var($sql);
    return $rowcount;
}



/*****************************************************************
 ** Like WP REST API -end  (not used ) *******
 ---old model like
 ******************************************************/

/**
 *
 * Registers REST API endpoints 
 *
 * @since 1.0.0
 */


//add_action('rest_api_init', 'get_Liked_Post_Meta_Data_InfoRegister');

function get_Liked_Post_Meta_Data_InfoRegister()
{
    register_rest_route('wp/v2', '/stnc_like2/id/(?P<id>[\d]+)',
        array(
            'methods' => 'GET',
            'callback' => 'get_Liked_Post_Meta_Data_Info',
            'permission_callback' => function ($request) {
                return is_user_logged_in();
            },
        )
    );

}
/**
 * get post meta for _liked
 *
 * @since 1.2.0
 * @param WP_REST_Request $request The request sent from WP REST API.
 * @return array Gets quiz list
 */
function get_Liked_Post_Meta_Data_Info(WP_REST_Request $request)
{
    $postID = $request['id'];
    $result = (get_post_meta($postID, '_liked', true));

    if ($result == '' or $result == 'NaN') {
        return $result = 0;
    }

    return $result;
}


/*****************************************************************
 ** post sonrasına _liked meta data ekler ı  (not used ) *******
 ---old model like
 ******************************************************/

 //not used
//add_action('rest_api_init', 'stnc_register_ulike');
function stnc_register_ulike()
{
    register_rest_field(
        'post',
        '_liked',
        array('get_callback' => 'stnc_get_ulike',
            'update_callback' => 'stnc_update_ulike',
            'schema' => null));
}


/**
 * Handler for getting custom field data.
 */
function stnc_get_ulike($object, $field_name, $request)
{
    return get_post_meta($object['id'], $field_name);
}

/**
 * Handler for updating custom field data.
 */
function stnc_update_ulike($value, $object, $field_name)
{
    if (!$value || !is_string($value)) {
        return;
    }
    return update_post_meta($object->ID, $field_name, strip_tags($value));
}

