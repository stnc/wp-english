<?php

function stnc_load_textdomain()
{
    load_plugin_textdomain('stnc', false, dirname(plugin_basename(__FILE__)) . '/i18n/languages/');
}

add_action('plugins_loaded', 'stnc_load_textdomain');

global $wpdb;
$tableNameMain = $wpdb->prefix . 'stnc_cat_quiz';


function stncCatQuiz_install()
{
    global $wpdb;
    global $tableNameMain;



	$charset_collate = $wpdb->get_charset_collate();

    // if ($wpdb->get_var("SHOW TABLES LIKE '$tableNameMain'") != $tableNameMain) {
      
        $sql = "CREATE TABLE IF NOT EXISTS $tableNameMain (
            result_id INT NOT NULL AUTO_INCREMENT,
            quiz_id INT NOT NULL,
             user_id INT NOT NULL,
            post_id INT NOT NULL,
            quiz_name TEXT DEFAULT NULL,
            point_score INT DEFAULT NULL,
            correct_score int(11) unsigned zerofill DEFAULT NULL,
            correct int(11) unsigned zerofill DEFAULT NULL,
            total INT DEFAULT NULL,
            user_ip varchar(255) DEFAULT NULL,
            -- time_taken TEXT NOT NULL,
            -- time_taken_real DATETIME NOT NULL,
            quiz_results TEXT DEFAULT NULL,
            deleted INT DEFAULT NULL,
            request_type tinyint(4) DEFAULT NULL,
            PRIMARY KEY  (result_id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    // }



}

register_activation_hook(__FILE__, 'stncCatQuiz_install');

function stncCatQuiz_remove_database()
{

    global $wpdb;
    global $tableNameMain;


    $sql = "DROP TABLE IF EXISTS $tableNameMain";
    $wpdb->query($sql);


    //  delete_option("my_plugin_db_version");
}

register_uninstall_hook(__FILE__, 'stncCatQuiz_remove_database');

// register_deactivation_hook( __FILE__, 'stncCatQuiz_remove_database' );
add_action('admin_init','stncCatQuiz_install');

// add_action('admin_init','stncCatQuiz_remove_database');