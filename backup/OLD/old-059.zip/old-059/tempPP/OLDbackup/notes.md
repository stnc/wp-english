https://codepen.io/desandro/pen/YzPMBx



resım ekleyebilme 
geçmiş kiracılar 
bekleyen firma listesi 
harita yukleyici çalışmıyor ve onun header 
ana ekranın veritabanından gelmesi gerekiyor 
firma boşaltma işlemi nasıl olacak 
anasayfada firmalar listesi 

binalar ansayfasında toplam metrekare ve kac ofıs ve hangı renklerde olacak gibi şeye bak 
aynı kapı numarasında fırma var mı yok mu 
yenı eklerken kapı numarası na bakılmalı belkı update ıcınde 



mail sisteminin çalışması lazım stmp mail etkinleşecek 
sticky menu ne olacak 

yayına alınca cron ıslerı ve kıosk un yolunun degısmesı gerekıyor 

https://yourstory.com/companies   
https://www.rtp.org/directory-map/
https://en.yellowpages.com.tr/restaurants-c

  https://www.yazilimbilisim.net/javascript/jquery/jquery-datepicker-turkce-tarih-secme/

---- haritahtml ye gecince teknokats olunca harita yuklenmeli 

https://www.jquery-az.com/bootstrap-tooltip-simple-and-customized-tooltips-demos/



css hover olayı 
https://codepen.io/simicigor/pen/ZEpJEBY


https://chandranrahul.wordpress.com/2018/01/03/session-based-flash-messages-in-wordpress/


    
  //https://wordpress.stackexchange.com/questions/385544/wpdb-update-table 
  //https://www.codegrepper.com/code-examples/php/frameworks/wordpress/wpdb+update+query+in+wordpress

  
  
  https://www.pngtosvg.com/ 
  https://code-boxx.com/drag-drop-sortable-list-javascript/#sec-download 
  https://github.com/eyeofchaos/eocjsNewsticker 
 https://www.freecodecamp.org/news/use-svg-images-in-css-html/ 

 https://xd.adobe.com/view/8af0288c-7757-49d4-9de4-0439f021d723-dfa3/
https://stackoverflow.com/questions/29991284/php-get-svg-tag-from-svg-file-and-show-it-in-html-in-div 


https://wordpress.stackexchange.com/questions/186315/how-to-use-update-and-delete-query-in-wordpress

wp_redirect 
https://wordpress.stackexchange.com/questions/82857/how-to-call-wp3-5-media-library-manager

https://wordpress.stackexchange.com/questions/198781/wordpress-ajax-file-upload-frontend




https://www.antalyateknokent.com.tr/tr/ar-ge-3-binasi/kod-yazilim.html

sağ tıklama  https://www.google.com/search?q=javasript+right+click+dropdown-toggle&rlz=1C1GCEA_enTR988TR988&sxsrf=APq-WBuubAcuhx_QrZj1F-IgAGONkD3_2w%3A1646816350342&ei=XmwoYt7_E9aTxc8P7Om0kA0&ved=0ahUKEwjepsn81Lj2AhXWSfEDHew0DdIQ4dUDCA4&uact=5&oq=javasript+right+click+dropdown-toggle&gs_lcp=Cgdnd3Mtd2l6EAM6BwgAEEcQsAM6BAgAEA06BggAEA0QHkoECEEYAEoECEYYAFBsWNwCYPwGaAFwAXgAgAHEAYgB6QKSAQMwLjKYAQCgAQGgAQLIAQjAAQE&sclient=gws-wiz
olayı evetnt 
https://jsfiddle.net/djibe89/qej2ppcq



tarayica sayfa aciksa kapatilsin mi olayi 
Changes you made may not be saved.
https://www.google.com/search?q=javascr%27pt+Changes+you+made+may+not+be+saved.&rlz=1C1FKPE_trTR967TR967&oq=javascr%27pt+Changes+you+made+may+not+be+saved.&aqs=chrome..69i57.2219j0j7&sourceid=chrome&ie=UTF-8
