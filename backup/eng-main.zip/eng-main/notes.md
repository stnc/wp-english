https://calebjacob.github.io/tooltipster/


https://www.tercihyazilim.com/Page/justify-content-css-ozellikleri


https://promova.com/english-grammar/modal-verbs-in-english


https://promova.com/english-grammar/list-of-conjunctions-in-english

        
https://www.englishcentral.com/blog/ingilizce-for-with-to-about-by-around-of-kullanimi-ve-ornek-cumleler/


https://preply.com/en/blog/list-of-prepositions/

   

   https://github.com/pro-dev-ph/bootstrap-simple-admin-template    ---- bootsrap theme 