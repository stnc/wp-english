import React from 'react';
import Settings from './components/Settings';

function App() {
    return(
        <React.Fragment>
            <Settings />
        </React.Fragment>
    )
}
export default App;