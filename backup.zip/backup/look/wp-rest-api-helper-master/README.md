# wp-rest-api-helper
A helper plugin to get necessary values in api end points
