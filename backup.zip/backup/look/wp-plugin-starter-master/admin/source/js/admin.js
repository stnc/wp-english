;(function($) {
    "use strict";
    console.log('Admin loaded');
})(jQuery);