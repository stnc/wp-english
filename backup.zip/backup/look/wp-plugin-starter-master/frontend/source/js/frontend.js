;(function($) {
    "use strict";
    console.log( 'Frontend Loaded' );

})(jQuery);